public interface Envenenable<T> {
    void absorberVeneno(T veneno);
}

