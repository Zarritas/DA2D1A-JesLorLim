public class Maligna extends Rana implements Depredador, Venenoso<Object, Bratacotoxina> {
    public Maligna(String nombre) {
        super(nombre);
    }

    @Override
    public void cazar() {
        System.out.println("Las ranas malignas cazamos de noche");
    }

    @Override
    public void nadar() {
        System.out.println("Soy una rana maligna nadadora");
    }

    @Override
    public void envenenar(Object victima, Bratacotoxina b) {
        if (victima instanceof Envenenable) {
            System.out.printf("¡Soy una %s y lanzo mi veneno %s a un %s y lo mato bien muerto!\n",
                    this, b, victima);
            ((Envenenable)victima).absorberVeneno(b);
        } else
            mostrarNoEnvenenable(victima);
    }

}

