public interface Nadador {
    void nadar();
    default void flotar() {
        System.out.println("Floto mejor que un globo");
    }
}

