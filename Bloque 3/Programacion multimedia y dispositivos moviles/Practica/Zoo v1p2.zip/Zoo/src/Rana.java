public abstract class Rana extends Anfibio {
    public Rana(String nombre) {
        super(nombre);
    }
}

