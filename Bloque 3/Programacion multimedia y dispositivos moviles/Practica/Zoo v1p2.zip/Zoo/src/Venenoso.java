public interface Venenoso<T,U> {
    void envenenar(T victima, U veneno);
    default void mostrarNoEnvenenable(T victima) {
        System.out.println("No es posible envenenar a "+victima+" porque no es envenenable");
    }
}

