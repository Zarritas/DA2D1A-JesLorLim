public class Veneno {
    @Override
    public String toString() {
        return "veneno";
    }
}
