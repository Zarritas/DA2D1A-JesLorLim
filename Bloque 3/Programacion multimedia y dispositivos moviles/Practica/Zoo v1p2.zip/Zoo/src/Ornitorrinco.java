public class Ornitorrinco extends Mamifero
        implements Buceador, Carnivoro, Depredador, Oviparo, Presa, Venenoso<Animal, Veneno> {
    public Ornitorrinco(String nombre) {
        super(nombre);
    }

    @Override
    public void comerCarne() {
        System.out.println("Qué rica está la carne de los animales que cazo");
    }

    @Override
    protected void comer() {
        System.out.println();
    }

    @Override
    public void nadar() {
        System.out.println("Los ornitorrincos nadamos");
    }

    @Override
    public void flotar() {
        System.out.println("Soy un ornitorrinco que flota");
    }

    @Override
    public void bucear() {
        System.out.println("Soy un ornitorrinco que bucea");
    }

    @Override
    public void cazar() {
        System.out.println("Soy un ornitorrinco que caza");
    }

    @Override
    public void ponerHuevos() {
        System.out.println("A veces pongo huevos");
    }

    @Override
    public void huir() {
        System.out.println("No me gusta huir pero a veces debo huir");
    }

    @Override
    public void envenenar(Animal victima, Veneno veneno) {
        System.out.printf("Soy %s y he envenenado al animal %s con %s\n", this, victima, veneno);
        victima.absorberVeneno(veneno);
    }
}

