public interface Carnivoro {
    void comerCarne();
}
