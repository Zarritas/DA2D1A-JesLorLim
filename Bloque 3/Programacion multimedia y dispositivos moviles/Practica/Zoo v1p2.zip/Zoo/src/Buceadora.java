public class Buceadora extends Rana implements Buceador {
    public Buceadora(String nombre) {
        super(nombre);
    }

    @Override
    public void bucear() {
        System.out.println("Soy una rana buceadora que bucea hasta las profundidades");
    }

    @Override
    public void nadar() {
        System.out.println("¡Las ranas buceadoras también flotamos!");
    }
}

