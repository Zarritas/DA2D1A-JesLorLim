public class Bratacotoxina extends Veneno {
    @Override
    public String toString() {
        return super.toString()+" bratacotoxina";
    }
}

