import java.util.Objects;

public class Leon extends Mamifero {
    private boolean melena;

    public Leon(String nombre, boolean melena) {
        super(nombre);
        this.melena = melena;
    }

    @Override
    protected void comer() {
        System.out.println("¡Me encanta la carne fresca!");
    }

    protected void cazar() {
        System.out.println("Soy un león y voy a cazar alguna presa para comérmela");
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Leon)) return false;
        if (!super.equals(o)) return false;
        Leon leon = (Leon) o;
        return melena == leon.melena;
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), melena);
    }

    @Override
    public String toString() {
        return super.toString()+ " | Melena " + (melena ? "SI" : "NO");
    }
}

