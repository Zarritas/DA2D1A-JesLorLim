public abstract class Anfibio extends Animal implements Nadador {
    public Anfibio(String nombre) {
        super(nombre);
    }

    @Override
    protected void comer() {
        System.out.println("Como comida de anfibio. ¡Algo húmeda!");
    }
}

