public class Oso extends Mamifero
        implements Depredador, Omnivoro, Nadador  {
    public Oso(String nombre) {
        super(nombre);
    }

    @Override
    public void cazar() {
        System.out.println("Puedo cazar hasta un enorme jabalí si me lo propongo");
    }

    @Override
    protected void comer() {
        System.out.println("Soy un oso que come");
    }

    @Override
    public void comerCarne() {
        System.out.println("Soy un oso que come carne");
    }

    @Override
    public void comerVegetales() {
        System.out.println("Soy un oso que come vegetales");
    }

    @Override
    public void nadar() {
        System.out.println("Los osos sabemos nadar.");
    }

    @Override
    public void comerPeces() {
        System.out.println("Soy un oso que come peces");
    }
}
