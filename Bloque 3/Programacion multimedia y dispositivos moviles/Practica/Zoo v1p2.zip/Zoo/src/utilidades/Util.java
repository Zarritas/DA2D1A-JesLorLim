package utilidades;

import org.jetbrains.annotations.NotNull;

/**
 * Métodos estáticos de utilidad en el proyecto
 */
public class Util {
    private Util() {}

    /**
     * Genera cadena de formato para mostrar datos tabulados
     * @param s     Datos a mostrar en cada columna
     * @return      Cadena de formato para ser usada con printf o String.format
     * @throws      IllegalArgumentException si la longitud de s es 0
     */
    public static String generarFormato(@NotNull String[] s) {
        if (s.length==0)
            throw new IllegalArgumentException("La longitud de s debe ser >=1 (longitud=0)");
        final String FORMATO = "%%-%ds ";
        StringBuilder f =new StringBuilder();
        for (String dato: s)
            f.append(String.format(FORMATO, dato.length()));
        f.deleteCharAt(f.length()-1);
        return f.toString();
    }

    /**
     * Devuelve la representación en modo texto de dos objetos separadas por una flecha
     * usando un carácter UNICODE para la flecha (\u27aa)
     * @param o1    Objeto 1
     * @param o2    Objeto 2
     * @return      o1.toString() -> o2.toString()
     */
    public static String flecha(@NotNull Object o1, @NotNull Object o2) {
        return o1 + " \u27aa " + o2;
    }
}

