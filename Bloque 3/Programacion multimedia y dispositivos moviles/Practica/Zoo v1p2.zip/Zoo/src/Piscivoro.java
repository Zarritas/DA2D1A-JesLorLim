public interface Piscivoro {
    void comerPeces();
}
