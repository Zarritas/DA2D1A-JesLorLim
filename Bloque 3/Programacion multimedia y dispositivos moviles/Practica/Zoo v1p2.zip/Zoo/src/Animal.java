import org.jetbrains.annotations.NotNull;

import java.util.Comparator;
import java.util.Objects;

public abstract class Animal implements Envenenable<Veneno>, Comparable<Animal> {
    private static int contador=0;
    private int numero;                 // AUTOINCREMENTADO, PRIMERO=1
    private String nombre;              // NO NULO, NO VACIO, NO BLANCO
    private int peso;                   // >=0 (kg)

    public Animal(String nombre) {
        setNombre(nombre);
        numero = ++contador;            // Al final para evitar autoincremento del contador en caso de fallo
                                        // al crear un objeto Animal. Esto tendrá más sentido cuando usemos
                                        // excepciones en vez de aserciones ya que en el primer caso el programa
                                        // podría continuar sin finalizar como en el caso de las aserciones
    }

    protected abstract void comer();

    protected int getNumero() {
        return numero;
    }

    protected final String getNombre() { return nombre; }

    protected final void setNombre(@NotNull String nombre) {
        assert !nombre.isEmpty(): "El nombre de un animal no puede estar vacío";
        assert !nombre.isBlank():
                "El nombre de un animal no puede estar formado solo por caracteres de espaciado en blanco";
        this.nombre = nombre;
    }

    protected int getPeso() {
        return peso;
    }

    /**
     * Modifica el peso de un animal
     * @param peso  Debe ser >=0 (kg)
     * @throws IllegalArgumentException si el peso es negativo
     */
    protected void setPeso(int peso) throws IllegalArgumentException {
        if (peso<0)
            throw new IllegalArgumentException(
                    String.format("El peso de un animal no puede ser negativo (peso=%d)", peso));
        this.peso = peso;
    }

    @Override
    public int compareTo(@NotNull Animal o) {
        return nombre.compareTo(o.nombre);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Animal)) return false;
        Animal animal = (Animal) o;
        return nombre.equals(animal.nombre);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre);
    }

    @Override
    public void absorberVeneno(Veneno veneno) {
        System.out.printf("Soy un %s ingiriendo veneno\n", getClass().getSimpleName());
    }

    @Override
    public String toString() {
        return String.format("[%s] %s %s (%d kg)", numero, getClass().getSimpleName(), nombre, peso);
    }

    protected static class ComparadorAnimalPesoInterna implements Comparator<Animal> {
        @Override
        public int compare(Animal o1, Animal o2) {
            return o1.peso - o2.peso;
        }
    }
}








