import org.jetbrains.annotations.NotNull;

import java.util.Objects;

public class Conejo extends Mamifero {
    private Pelaje pelaje;              // NO NULO

    public Conejo(String nombre, Pelaje pelaje) {
        super(nombre);
        setPelaje(pelaje);
    }

    @Override
    public void absorberVeneno(@NotNull Veneno veneno) {
        System.out.printf("Soy %s y estoy sufriendo un envenenamiento por %s\n", getNombre(), veneno);
    }

    @Override
    protected void comer() {
        System.out.println("Qué ricas están las zanahorias");
    }

    protected void huir() {
        System.out.println("Soy un conejo que huye");
    }

    private void setPelaje(@NotNull Pelaje pelaje) {
        this.pelaje = pelaje;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Conejo)) return false;
        if (!super.equals(o)) return false;
        Conejo conejo = (Conejo) o;
        return pelaje.equals(conejo.pelaje);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), pelaje);
    }

    @Override
    public String toString() {
        return super.toString()+" | Pelaje "+pelaje;
    }
}



























