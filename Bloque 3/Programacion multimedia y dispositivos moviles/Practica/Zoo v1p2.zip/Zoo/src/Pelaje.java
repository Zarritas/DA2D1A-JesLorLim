public enum Pelaje {
    ANGORA, COMUN, MIXTO, LARGO
}
