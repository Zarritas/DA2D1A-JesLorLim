public abstract class Mamifero extends Animal {
    public Mamifero(String nombre) {
        super(nombre);
    }

    protected void mamar() {
        System.out.println("Soy un "+getClass().getSimpleName()+" que mama");
    }
}



