public interface Depredador {
    void cazar();
}

