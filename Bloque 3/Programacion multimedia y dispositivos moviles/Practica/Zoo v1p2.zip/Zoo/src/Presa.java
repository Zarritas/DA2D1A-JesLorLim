public interface Presa {
    void huir();
}

