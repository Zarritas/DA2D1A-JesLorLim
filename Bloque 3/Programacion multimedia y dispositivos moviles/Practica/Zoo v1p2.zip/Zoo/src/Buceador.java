public interface Buceador extends Nadador {
    void bucear();
}

