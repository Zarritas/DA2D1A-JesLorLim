public interface Omnivoro extends Carnivoro, Herbivoro, Piscivoro {
}


