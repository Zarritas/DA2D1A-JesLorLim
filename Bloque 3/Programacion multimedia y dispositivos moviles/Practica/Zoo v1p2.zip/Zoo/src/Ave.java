public class Ave extends Animal implements Oviparo {
    public Ave(String nombre) {
        super(nombre);
    }

    @Override
    protected void comer() {
        System.out.println("Como comida de ave. ¡Muy nutritiva!");
    }

    @Override
    public void ponerHuevos() {
        System.out.println("Pongo huevos");
    }
}

