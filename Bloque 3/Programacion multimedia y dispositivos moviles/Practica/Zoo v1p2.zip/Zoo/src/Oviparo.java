public interface Oviparo {
    void ponerHuevos();
}

