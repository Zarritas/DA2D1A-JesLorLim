import org.jetbrains.annotations.NotNull;
import java.util.HashSet;

/**
 * En una jaula pueden haber animales de cualquier tipo pero no pueden existir dos animales iguales
 */
public class Jaula {
    private HashSet<Animal> animales;

    /**
     * Crea una jaula vacía
     */
    public Jaula() { animales = new HashSet<>(); }

    /**
     * Agregar un animal a la jaula si no existe ya en ella
     * @param a Animal
     */
    public void agregar(@NotNull Animal a) {
        animales.add(a);
    }

    public int numeroAnimales() {
        return animales.size();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("Animales enjaulados (%d): \n", numeroAnimales()));
        for (Animal a: animales) {
            sb.append(a);
            sb.append("\n");
        }
        return sb.toString();
    }

}


