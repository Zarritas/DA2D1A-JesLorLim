public interface Herbivoro {
    void comerVegetales();
}
