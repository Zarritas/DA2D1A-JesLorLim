import org.jetbrains.annotations.NotNull;

public class Robot {
    private static int contador=0;
    private int numero;             // AUTOINCREMENTADO, >=1
    private String nombre;          // NO NULO

    public Robot(@NotNull String nombre) {
        this.nombre = nombre;
        numero = ++contador;
    }

    @Override
    public String toString() {
        return String.format("[%s] %s", numero, nombre);
    }
}
