public enum TipoResultado {
    NENRAYA, TABLAS
}
