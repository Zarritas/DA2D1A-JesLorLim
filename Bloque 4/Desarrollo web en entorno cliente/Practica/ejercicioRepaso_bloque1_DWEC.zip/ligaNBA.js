const NPLAYERS = 25;
const NPX = 6;
