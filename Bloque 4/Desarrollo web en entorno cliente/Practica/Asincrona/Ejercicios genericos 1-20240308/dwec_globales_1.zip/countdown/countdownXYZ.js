"use strict"



// iniciar();