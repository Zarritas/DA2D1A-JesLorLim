const numFilas = 10;
const numColumnas = 5;


// iniciarSorteo();
