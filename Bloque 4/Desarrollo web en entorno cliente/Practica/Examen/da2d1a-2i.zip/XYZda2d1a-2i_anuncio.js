const fondos = ["crimson", "deepskyblue", "darkseagreen", "gold"];

const marcas = ["Ferrari", "Microsoft", "Starbucks", "Ferrero Rocher"];
