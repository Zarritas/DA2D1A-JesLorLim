let listaregistros = [];

function crearObjetosDirecciones() {}

function listarNombres() {}

function listarApellidos() {}

function listarDirecciones() {}

function listarTodo() {}

function asignarEventos() {}
