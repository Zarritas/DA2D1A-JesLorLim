'use strict'

function validarEntrada(){

}

function crearTabla() {

    const contenido = document.getElementById("zonadibujo");

    contenido.innerHTML = `<p>Este parrafo desaparece y aparece el tablero de dibujo</p>` ;
    
}

function activarTablero() {
    crearTabla();
}